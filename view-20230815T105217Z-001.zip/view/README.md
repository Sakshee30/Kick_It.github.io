# Football Project with Vue.js

> You can learn Standings, Results and Goal Kings.<br/>
> - Spor Toto Super League<br/>
> - TFF 1. League<br/>
> - TFF 2. League<br/>
> - Premier League<br/>
> - EFL Championship<br/>
> - League 1<br/>
> - League 2<br/>
> - Bundesliga<br/>
> - Bundesliga 2<br/>
> - Premiere League<br/>
> - Serie A<br/>
> - Serie B<br/>
> - LaLiga<br/>
> - LaLiga 2<br/>
> - Ligue 1<br/>
> - Ligue 2<br/>
> - Eredivisie<br/>
> - Eredivisie 2<br/>
> - Primeira Liga<br/>
> - Russian Premier<br/>
> - Brazil Serie<br/>
> - Brazil Serie B<br/>
> - Argentina Primera A Apertura<br/>
> - Argentina Primera A Clasura<br/>

> **[You can try](https://yunusemrealps.github.io/Football_Leagues_Info/)**

